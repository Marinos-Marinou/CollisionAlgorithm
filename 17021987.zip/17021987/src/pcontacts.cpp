#include <float.h>
#include <pcontacts.h>
#include <particle.h>


// Contact implementation
void ParticleContact::resolve(float duration)
{
    resolveVelocity(duration);
    resolveInterpenetration(duration);
}

float ParticleContact::calculateSeparatingVelocity() const
{
    Vector2 relativeVelocity = particle[0]->getVelocity();
    if (particle[1]) relativeVelocity -= particle[1]->getVelocity();
    return relativeVelocity * contactNormal;
}

void ParticleContact::resolveInterpenetration(float duration)
{
    // If we don't have any penetration, skip this step.
    if (penetration <= 0) return;
    // The movement of each object is based on their inverse mass, so
    // total that.
    float totalInverseMass = particle[0]->getInverseMass();
    if (particle[1]) totalInverseMass += particle[1]->getInverseMass();
    // If all particles have infinite mass, then we do nothing
    if (totalInverseMass <= 0) return;
    // Find the amount of penetration resolution per unit of inverse mass
    Vector2 movePerIMass = contactNormal * (penetration / totalInverseMass);
    // Calculate the the movement amounts
    particleMovement[0] = movePerIMass * particle[0]->getInverseMass();
    if (particle[1]) {
        particleMovement[1] = movePerIMass * -particle[1]->getInverseMass();
    }
    else {
        particleMovement[1].clear();
    }
    // Apply the penetration resolution
    particle[0]->setPosition(particle[0]->getPosition() + particleMovement[0]);
    if (particle[1]) {
        particle[1]->setPosition(particle[1]->getPosition() + particleMovement[1]);
    }
}

void ParticleContactResolver::updateInterpenetrations(ParticleContact* contactArray,
    unsigned numContacts, unsigned maxIndex) {
    Vector2* move = contactArray[maxIndex].particleMovement;
    for (int i = 0; i < numContacts; i++)
    {
        if (contactArray[i].particle[0] == contactArray[maxIndex].particle[0])
        {
            contactArray[i].penetration -= move[0] * contactArray[i].contactNormal;
        }
        else if (contactArray[i].particle[0] == contactArray[maxIndex].particle[1])
        {
            contactArray[i].penetration -= move[1] * contactArray[i].contactNormal;
        }
        if (contactArray[i].particle[1])
        {
            if (contactArray[i].particle[1] == contactArray[maxIndex].particle[0])
            {
                contactArray[i].penetration += move[0] * contactArray[i].contactNormal;
            }
            else if (contactArray[i].particle[1] == contactArray[maxIndex].particle[1])
            {
                contactArray[i].penetration += move[1] * contactArray[i].contactNormal;
            }
        }
    }
}

void ParticleContact::resolveVelocity(float duration)
{
    // Find the velocity in the direction of the contact
    float separatingVelocity = calculateSeparatingVelocity();

    // Check if it needs to be resolved
    if (separatingVelocity > 0)
    {
        // The contact is either separating, or stationary - there's
        // no impulse required.
        return;
    }

    // Calculate the new separating velocity
    float newSepVelocity = -separatingVelocity * restitution;
    float deltaVelocity = newSepVelocity - separatingVelocity;

    // We apply the change in velocity to each object in proportion to
    // their inverse mass (i.e. those with lower inverse mass [higher
    // actual mass] get less change in velocity)..
    float totalInverseMass = particle[0]->getInverseMass();
    if (particle[1]) totalInverseMass += particle[1]->getInverseMass();

    // If all particles have infinite mass, then impulses have no effect
    if (totalInverseMass <= 0) return;

    // Calculate the impulse to apply
    float impulse = deltaVelocity / totalInverseMass;

    // Find the amount of impulse per unit of inverse mass
    Vector2 impulsePerIMass = contactNormal * impulse;

    // Apply impulses: they are applied in the direction of the contact,
    // and are proportional to the inverse mass.
    particle[0]->setVelocity(particle[0]->getVelocity() +
        impulsePerIMass * particle[0]->getInverseMass()
        );
    if (particle[1])
    {
        // Particle 1 goes in the opposite direction
        particle[1]->setVelocity(particle[1]->getVelocity() +
            impulsePerIMass * -particle[1]->getInverseMass()
            );
    }
}

ParticleContactResolver::ParticleContactResolver(unsigned iterations)
:
iterations(iterations)
{
}

void ParticleContactResolver::setIterations(unsigned iterations)
{
    ParticleContactResolver::iterations = iterations;
}

void ParticleContactResolver::resolveContacts(ParticleContact *contactArray,
                                              unsigned numContacts,
                                              float duration)
{
    
    unsigned i;

    iterationsUsed = 0;
    while(iterationsUsed < iterations)
    {
        // Find the contact with the largest closing velocity;
        float max = DBL_MAX;
        unsigned maxIndex = numContacts;
        for (i = 0; i < numContacts; i++)
        {
            float sepVel = contactArray[i].calculateSeparatingVelocity();
            if (sepVel < max &&
                (sepVel < 0 || contactArray[i].penetration > 0))
            {
                max = sepVel;
                maxIndex = i;
            }
        }
         //Do we have anything worth resolving?
        if (maxIndex == numContacts) break;

        // Resolve this contact
        contactArray[maxIndex].resolve(duration);

        if (updatePenetration) updateInterpenetrations(contactArray, numContacts,
            maxIndex);

        iterationsUsed++;
    }

}
unsigned ParticleCollision::addContact(ParticleContact* contact, unsigned limit)const
{

    const static float restitution = 1.0f;
    unsigned used = 0;

    for (int i = 0; i < blobNo; i++)
    {
        for (int j = 0; j < blobNo; j++)
        {
            if (searchCollision(i, j) == true && i != j)
            {
                Vector2 toParticle = particle[i]->getPosition();
                contact->contactNormal = toParticle.unit();
                contact->restitution = restitution;
                contact->particle[0] = particle[i];
                contact->particle[1] = particle[j];
                contact->penetration = particle[i]->getRadius() - toParticle.squareMagnitude();
                used++;
                contact++;
            }
        }
    }
    return used;
}

bool ParticleCollision::checkCollision(int i, int j)const
{
    float x = particle[i]->getPosition().x - particle[j]->getPosition().x;
    float y = particle[i]->getPosition().y - particle[j]->getPosition().y;
    float x2 = x * x;
    float y2 = y * y;
    float distance = sqrt(x2 + y2);
    if (distance < particle[i]->getRadius() + particle[j]->getRadius())
    {
        return true;
    }
    else
    {
        return false;
    }
}