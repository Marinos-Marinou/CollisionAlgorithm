/*
 * The Blob demo.
 *
 */
#include <gl/glut.h>
#include "app.h"
#include "coreMath.h"
#include "pcontacts.h"
#include "pworld.h"
#include <stdio.h>
#include <cassert>
#include"particle.h"

const Vector2 Vector2::GRAVITY = Vector2(0,-9.81);

/**
 * Platforms are two dimensional: lines on which the 
 * particles can rest. Platforms are also contact generators for the physics.
 */

class Platform : public ParticleContactGenerator
{
public:
    Vector2 start;
    Vector2 end;
    /**
     * Holds a pointer to the particles we're checking for collisions with. 
     */
    Particle *particle;

    virtual unsigned addContact(
        ParticleContact *contact, 
        unsigned limit
        ) const;
};

unsigned Platform::addContact(ParticleContact *contact, 
                              unsigned limit) const
{
    
	//const static float restitution = 0.8f;
	const static float restitution = 1.0f;
	unsigned used = 0;
        
        // Check for penetration
        Vector2 toParticle = particle->getPosition() - start;
        Vector2 lineDirection = end - start;

        float projected = toParticle * lineDirection;
        float platformSqLength = lineDirection.squareMagnitude();
		float squareRadius = particle->getRadius()*particle->getRadius();;
		 
       if (projected <= 0)
       {
		
            // The blob is nearest to the start point
            if (toParticle.squareMagnitude() < squareRadius)
            {
                // We have a collision
                contact->contactNormal = toParticle.unit();
                contact->restitution = restitution;
                contact->particle[0] = particle;
                contact->particle[1] = 0;
                contact->penetration = particle->getRadius() - toParticle.magnitude();
                used ++;
                contact ++;
            }
            
       }
        else if (projected >= platformSqLength)
        {
            // The blob is nearest to the end point
            toParticle = particle->getPosition() - end;
            if (toParticle.squareMagnitude() < squareRadius)
		    {
                // We have a collision
                contact->contactNormal = toParticle.unit();
                contact->restitution = restitution;
                contact->particle[0] = particle;
                contact->particle[1] = 0;
                contact->penetration = particle->getRadius() - toParticle.magnitude();
                used ++;            
                contact ++;
            }
        }
        else
        {
            // the blob is nearest to the middle.
            float distanceToPlatform = toParticle.squareMagnitude() - projected*projected / platformSqLength;
            if (distanceToPlatform < squareRadius)
            {
                // We have a collision
                Vector2 closestPoint = start + lineDirection*(projected/platformSqLength);

                contact->contactNormal = (particle->getPosition()-closestPoint).unit();
				contact->restitution = restitution;
                contact->particle[0] = particle;
                contact->particle[1] = 0;
				contact->penetration = particle->getRadius() - sqrt(distanceToPlatform);
	            used ++;
                contact ++;
            }
        }

    return used;
}



class BlobDemo : public Application
{
    Particle *blob;

    Platform *platform;

    ParticleWorld world;

public:
    void update(Particle& particle);
    /** Creates a new demo object. */
    BlobDemo();
    virtual ~BlobDemo();

    /** Returns the window title for the demo. */
    virtual const char* getTitle();

    /** Display the particles. */
    virtual void display();

    /** Update the particle positions. */
    void out_of_box_resolve(Particle& particle);

    bool out_of_box_test(Particle& particle);

    void box_collision_resolve(Particle& particle);
};

void BlobDemo::out_of_box_resolve(Particle& particle)
{
    Vector2 position = particle.getPosition();
    Vector2 velocity = particle.getVelocity();
    int radius = particle.getRadius();

    if (position.x > Application::width - radius)
        position.x = Application::width - radius;
    else if (position.x < -Application::width + radius)
        position.x = -Application::width + radius;

    if (position.y > Application::height - radius)
        position.y = Application::height - radius;
    else if (position.y < -Application::height + radius)
        position.y = -Application::height + radius;

    particle.setPosition(position.x, position.y);
}

void BlobDemo::box_collision_resolve(Particle& particle)
{
    Vector2 position = particle.getPosition();
    Vector2 velocity = particle.getVelocity();
    int radius = particle.getRadius();

    float w = Application::width;
    float h = Application::height;

    if (position.x > w - radius || position.x < -w + radius)
        particle.setVelocity(-velocity.x, velocity.y);
    if (position.y > h - radius || position.y < -h + radius)
        particle.setVelocity(velocity.x, -velocity.y);
}

bool BlobDemo::out_of_box_test(Particle& particle)
{
    Vector2 position = particle.getPosition();
    Vector2 velocity = particle.getVelocity();
    int radius = particle.getRadius();

    if ((position.x > Application::width - radius) || (position.x < -Application::width + radius))return true;
    if ((position.y > Application::height - radius) || (position.y < -Application::height + radius))return true;

    return false;
}

void BlobDemo::update(Particle &particle)
{
    float radius = particle.getRadius();
    // Recenter the axes
    float duration = timeinterval / 1000;

    float g = 9.81;
    for (int i = 0; i < blobNo; i++)
    {
        
        int radius = blob->getRadius();
        Vector2 velocity = blob->getVelocity();
        float dragCoefficient = 0.007 * radius * radius * velocity.magnitude() * velocity.magnitude();
        Vector2 dragForce = velocity;

        //produce dragforce
        dragForce.normalise();
        dragForce *= -dragCoefficient;

        blob[i]->addForce(Vector2(0, -g * blob[i]->getMass()));
        blob[i]->addForce(dragForce);

        box_collision_resolve(blob[i]);
        if (out_of_box_test(blob[i]))
            out_of_box_resolve(blob[i]);
    }

    // Run the simulation
    world.runPhysics(duration);
    particle.integrate(duration);

 /*   out_of_box_resolve(particle);

    if (out_of_box_test(particle))
        out_of_box_resolve(particle);*/

    Application::update();
}

// Method definitions
BlobDemo::BlobDemo():world(2, 1)
{
	width = 400; height = 400; 
	nRange = 100.0;

    // Create the blob storage
    blob = new Particle;
	   
    // Create the platform
	platform = new Platform;
	
	platform->start = Vector2 ( -50.0, 0.0 );
	platform->end   = Vector2 (  50.0, 20.0 );

    // Make sure the platform knows which particle it should collide with.
    platform->particle = blob;

    world.getContactGenerators().push_back(platform);

    // Create the blob
	blob->setPosition(0.0, 90.0);
	blob->setRadius( 5 );
    blob->setVelocity(0,0); 
    //blob->setDamping(0.9);
	blob->setDamping(1.0);
    blob->setAcceleration(Vector2::GRAVITY * 20.0f ); 

    blob->setMass(30.0f);
    blob->clearAccumulator();
    world.getParticles().push_back(blob);
}


BlobDemo::~BlobDemo()
{
    delete blob;
}

void BlobDemo::display()
{
  Application::display();

  const Vector2 &p0 = platform->start;
  const Vector2 &p1 = platform->end;

  //const Vector2 &p2 = platform2->start;
  //const Vector2 &p3 = platform2->end;

   glBegin(GL_LINES);
   glColor3f(0,1,1);
   glVertex2f(p0.x, p0.y);
   glVertex2f(p1.x, p1.y);
   glEnd();

   glColor3f(1,0,0); 

    const Vector2 &p = blob->getPosition();
	glPushMatrix();
	glTranslatef(p.x, p.y, 0);
	glutSolidSphere(blob->getRadius(), 12, 12);
	glPopMatrix();

	glutSwapBuffers();
    
}

const char* BlobDemo::getTitle()
{
    return "Blob Demo";
}

/**
 * Called by the common demo framework to create an application
 * object (with new) and return a pointer.
 */
Application* getApplication()
{
    return new BlobDemo();
}